// HER. FOUNDATION — site scripts

document.addEventListener('DOMContentLoaded', function () {

  // Footer year
  var yearEl = document.getElementById('year');
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }

  // Mobile navigation toggle
  var navToggle = document.getElementById('navToggle');
  var primaryNav = document.getElementById('primaryNav');

  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', function () {
      var isOpen = primaryNav.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
      navToggle.setAttribute('aria-label', isOpen ? 'Close menu' : 'Open menu');
    });

    // Close the menu when a link is tapped (mobile)
    primaryNav.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        primaryNav.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
        navToggle.setAttribute('aria-label', 'Open menu');
      });
    });
  }

  // Enquiry form validation
  var form = document.getElementById('enquiryForm');
  if (form) {
    var nameInput = document.getElementById('name');
    var emailInput = document.getElementById('email');
    var nameError = document.getElementById('nameError');
    var emailError = document.getElementById('emailError');
    var status = document.getElementById('formStatus');

    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    function validate() {
      var valid = true;

      if (!nameInput.value.trim()) {
        nameError.textContent = 'Please enter your full name.';
        nameInput.classList.add('invalid');
        valid = false;
      } else {
        nameError.textContent = '';
        nameInput.classList.remove('invalid');
      }

      if (!emailInput.value.trim() || !emailPattern.test(emailInput.value.trim())) {
        emailError.textContent = 'Please enter a valid email address.';
        emailInput.classList.add('invalid');
        valid = false;
      } else {
        emailError.textContent = '';
        emailInput.classList.remove('invalid');
      }

      return valid;
    }

    form.addEventListener('submit', function (event) {
      event.preventDefault();

      if (!validate()) {
        status.textContent = 'Please fix the highlighted fields and try again.';
        status.className = 'form-status error';
        return;
      }

      // No backend is connected yet — this confirms receipt locally.
      status.textContent = 'Thank you! Your enquiry has been received. We will be in touch soon.';
      status.className = 'form-status success';
      form.reset();
    });

    [nameInput, emailInput].forEach(function (input) {
      input.addEventListener('blur', validate);
    });
  }

});
